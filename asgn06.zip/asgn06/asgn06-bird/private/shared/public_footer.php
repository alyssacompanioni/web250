    
  <footer>
    <?php include(SHARED_PATH . '/public_copyright_disclaimer.php'); ?>
  </footer>
  
  </body>
</html>
