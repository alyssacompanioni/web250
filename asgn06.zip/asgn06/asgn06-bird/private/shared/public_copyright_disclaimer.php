<p>Copyright <?php echo date('Y'); ?>, Bird Challenge</p>

<p>This bird project is solely for the creation and development of OOP and PHP and WEB250.</p>
