<?php 

define("DB_SERVER", "localhost");
define("DB_USER", "uxyaopmbbarls");
define("DB_PASS", "bird_user1234");
define("DB_NAME", "dbzuvafpyyc48l");

?>
