<?php 

define("DB_SERVER", "localhost");
define("DB_USER", "bird_user");
define("DB_PASS", "BirdPass");
define("DB_NAME", "bird");

?>
