<?php
// step3_array_constructor.php
declare(strict_types=1);

class Guitar
{
    public ?string $brand;
    public ?string $model;
    public ?float $price;

    // Constructor now accepts an array of args
    public function __construct($args = [])
    {
        $this->brand = $args['brand'] ?? null;
        $this->model = $args['model'] ?? null;
        $this->price = $args['price'] ?? null;
    }

    public function summary(): string
    {
        $brand = $this->brand ?? "Unknown Brand";
        $model = $this->model ?? "Unknown Model";
        $price = $this->price !== null
            ? "$" . number_format($this->price, 2)
            : "Price not available";

        return "{$brand} {$model} - {$price}";
    }
}

// Examples
$g1 = new Guitar([
    "brand" => "Fender",
    "model" => "Jazzmaster",
    "price" => 1199.00
]);

$g2 = new Guitar([
    "brand" => "Epiphone",
    "model" => "SG Special"
]);

$g3 = new Guitar([]); // all nulls

echo $g1->summary() . PHP_EOL;
echo $g2->summary() . PHP_EOL;
echo $g3->summary() . PHP_EOL;
