<?php
// step2_clone.php
declare(strict_types=1);

class Guitar
{
    public string $brand;
    public string $model;
    public float $price;

    public function __construct(string $brand, string $model, float $price)
    {
        $this->brand  = $brand;
        $this->model  = $model;
        $this->price  = $price;
    }

    public function summary()
    {
        return "{$this->brand} {$this->model} - $" . number_format($this->price, 2);
    }
}

// Start with one instrument
$original = new Guitar("Ibanez", "RG450DX", 499.00);

// Clone it
$clone = clone $original;

// Modify the clone
$clone->model = "RG550";
$clone->price = 899.00;

// Compare
echo "Original: " . $original->summary() . "<br>";
echo "Clone: "    . $clone->summary()    . "<br>";
