<?php
// step1_guitar.php
declare(strict_types=1);

class Guitar
{
    public string $brand;
    public string $model;
    public float $price;

    public function __construct(string $brand, string $model, float $price)
    {
        $this->brand = $brand;
        $this->model = $model;
        $this->price = $price;
    }

    public function summary(): string
    {
        return "{$this->brand} {$this->model} - $" . number_format($this->price, 2);
    }
}

// Demo
$g1 = new Guitar("Fender", "Player Telecaster", 799.99);
$g2 = new Guitar("Gibson", "Les Paul Studio", 1699.00);

echo $g1->summary() . PHP_EOL;
echo $g2->summary() . PHP_EOL;
